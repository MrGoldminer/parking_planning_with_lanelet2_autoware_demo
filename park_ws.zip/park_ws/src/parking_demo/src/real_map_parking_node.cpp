
#include <algorithm>
#include <cmath>
// Replace the entire file with a clean, single copy.
#include <ros/ros.h>
#include <ros/package.h>
#include <visualization_msgs/MarkerArray.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Pose2D.h>
#include <tf/transform_broadcaster.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>
#include <cmath>
#include <random>
#include <algorithm>
#include <queue>

// ================= 基础结构定义 =================
struct NodePoint {
    long long id;
    double lat;
    double lon;
    // 局部坐标 (米)
    double x;
    double y;
};

struct Way {
    long long id;
    std::vector<long long> node_refs;
    std::string relation; // "Successor", "Left", etc.
    std::string subtype; // e.g., "dashed" or "solid"
    std::string wtype; // e.g., "line_thin"
};

struct Relation {
    long long id;
    std::vector<long long> member_way_refs; // only keep way members for visualization
    std::string type; // e.g. "multipolygon"
};

struct ParkingSpot {
    long long id; // way id or node id
    double x = 0.0;
    double y = 0.0;
    bool from_way = false; // true if based on way, false if node
};

// ================= 数学与工具类 =================
class MapTools {
public:
    // 简单的墨卡托投影近似，以第一个点为原点
    static void projectToLocal(std::map<long long, NodePoint>& nodes) {
        if (nodes.empty()) return;

        // 取第一个点作为原点
        auto it = nodes.begin();
        origin_lat_ = it->second.lat;
        origin_lon_ = it->second.lon;
        double R = 6378137.0; // 地球半径

        for (auto& pair : nodes) {
            double dlat = pair.second.lat - origin_lat_;
            double dlon = pair.second.lon - origin_lon_;
            double lat_rad = origin_lat_ * M_PI / 180.0;

            // x = 东向 (Lon), y = 北向 (Lat)
            pair.second.x = R * (dlon * M_PI / 180.0) * cos(lat_rad);
            pair.second.y = R * (dlat * M_PI / 180.0);
        }
    }

    static double dist(const NodePoint& a, const NodePoint& b) {
        return std::sqrt(std::pow(a.x - b.x, 2) + std::pow(a.y - b.y, 2));
    }

    // project a single lat/lon pair to local coordinates using an origin
    static void projectPoint(double origin_lat, double origin_lon, double lat, double lon, double &out_x, double &out_y) {
        double R = 6378137.0;
        double dlat = lat - origin_lat;
        double dlon = lon - origin_lon;
        double lat_rad = origin_lat * M_PI / 180.0;
        out_x = R * (dlon * M_PI / 180.0) * cos(lat_rad);
        out_y = R * (dlat * M_PI / 180.0);
    }

    // getters for the origin used in projectToLocal
    static double getOriginLat() { return origin_lat_; }
    static double getOriginLon() { return origin_lon_; }
private:
    static double origin_lat_;
    static double origin_lon_;
};

// define static origin members
double MapTools::origin_lat_ = 0.0;
double MapTools::origin_lon_ = 0.0;

// ================= 主节点类 =================
class ParkingSystem {
private:
    ros::NodeHandle nh_;
    ros::Publisher car_pub_;
    ros::Publisher path_pub_;
    ros::Publisher pose_pub_;
    ros::Publisher ways_pub_;
    ros::Publisher relations_pub_;
    ros::Publisher nodes_pub_;
    ros::Publisher parking_pub_;
    ros::Timer loop_timer_;

    std::map<long long, NodePoint> nodes_map_;
    std::vector<Way> ways_;
    std::vector<Relation> relations_;
    std::vector<ParkingSpot> parking_spots_;
    // 邻接表用于图搜索: node_id -> list of connected node_ids
    std::map<long long, std::vector<long long>> adjacency_list_;

    // 车辆状态
    struct CarState {
        double x = 0.0;
        double y = 0.0;
        double theta = 0.0;
        double v = 0.0;
        double phi = 0.0; // steering
    } car_;
    // desired parking orientation (set during planning)
    double parking_target_theta_ = 1.72;
    // maximum allowed forward speed (m/s)
    double max_speed_ = 3.0;

    // 轨迹
    std::vector<CarState> global_plan_;
    int current_idx_ = 0;
    bool is_parking_mode_ = false;

public:
    ParkingSystem() {
    // separate publisher for the ego car so the map topic is not overwritten by frequent car updates
    car_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/car_marker", 10, false);
    // publish OSM features on dedicated topics for full-feature visualization
    ways_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/osm/ways", 1, true);
    relations_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/osm/relations", 1, true);
    nodes_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/osm/nodes", 1, true);
    parking_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/parking_spots", 1, true);
        path_pub_ = nh_.advertise<nav_msgs::Path>("/planned_path", 1, true);
        pose_pub_ = nh_.advertise<geometry_msgs::Pose2D>("/pose2d", 10);

        // 1. 加载地图
        std::string path = ros::package::getPath("parking_demo") + "/maps/parking_map.osm";
        if (!loadMap(path)) {
            ROS_ERROR("Failed to load map from %s. Make sure the file exists.", path.c_str());
            return; // 简单的错误处理
        }

        // 2. 坐标转换
        MapTools::projectToLocal(nodes_map_);
        buildGraph();
        publishMap();

        // 3. 规划任务
        planTask();

        // 4. 启动控制循环 (20Hz)
        loop_timer_ = nh_.createTimer(ros::Duration(0.05), &ParkingSystem::controlLoop, this);
    }

    // --- 简单的 XML 解析器 (避免 heavy dependencies) ---
    bool loadMap(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) return false;

        std::string line;
        while (std::getline(file, line)) {
            // 解析 Node
            if (line.find("<node") != std::string::npos) {
                NodePoint n;
                n.id = std::stoll(extractAttr(line, "id"));
                n.lat = std::stod(extractAttr(line, "lat"));
                n.lon = std::stod(extractAttr(line, "lon"));
                // check for inline tags or multi-line node children
                if (line.find("/>") == std::string::npos) {
                    // read children until </node>
                    std::string sub;
                    while (std::getline(file, sub) && sub.find("</node>") == std::string::npos) {
                        if (sub.find("<tag") != std::string::npos) {
                            std::string v = extractAttr(sub, "v");
                            if (v == "parking_space") {
                                ParkingSpot ps;
                                ps.id = n.id;
                                ps.from_way = false;
                                // projection to be computed later
                                parking_spots_.push_back(ps);
                            }
                        }
                    }
                }
                nodes_map_[n.id] = n;
            }
            // 解析 Way
            else if (line.find("<way") != std::string::npos) {
                Way w;
                w.id = std::stoll(extractAttr(line, "id"));
                // 读取 way 的子标签
                while (std::getline(file, line) && line.find("</way>") == std::string::npos) {
                    if (line.find("<nd") != std::string::npos) {
                        w.node_refs.push_back(std::stoll(extractAttr(line, "ref")));
                    }
                    if (line.find("<tag") != std::string::npos) {
                        std::string k = extractAttr(line, "k");
                        std::string v = extractAttr(line, "v");
                        if (k == "relation") {
                            w.relation = v;
                        }
                        if (k == "subtype") {
                            w.subtype = v;
                        }
                        if (k == "type") {
                            w.wtype = v;
                        }
                        if (v == "parking_space") {
                            // mark this way as a parking spot
                            ParkingSpot ps;
                            ps.id = w.id;
                            ps.from_way = true;
                            parking_spots_.push_back(ps);
                        }
                    }
                }
                ways_.push_back(w);
            }
            else if (line.find("<relation") != std::string::npos) {
                Relation r;
                r.id = std::stoll(extractAttr(line, "id"));
                // read members and tags until </relation>
                while (std::getline(file, line) && line.find("</relation>") == std::string::npos) {
                    if (line.find("<member") != std::string::npos) {
                        std::string type = extractAttr(line, "type");
                        if (type == "way") {
                            std::string ref = extractAttr(line, "ref");
                            if (!ref.empty()) r.member_way_refs.push_back(std::stoll(ref));
                        }
                    }
                    if (line.find("<tag") != std::string::npos) {
                        std::string k = extractAttr(line, "k");
                        std::string v = extractAttr(line, "v");
                        if (k == "type") r.type = v;
                    }
                }
                relations_.push_back(r);
            }
        }
        ROS_INFO("Loaded %lu nodes and %lu ways.", nodes_map_.size(), ways_.size());
        return true;
    }

    std::string extractAttr(const std::string& line, const std::string& key) {
        std::string search = key + "=\"";
        size_t start = line.find(search);
        if (start == std::string::npos) {
            search = key + "='"; // 尝试单引号
            start = line.find(search);
            if (start == std::string::npos) return "";
        }
        start += search.length();
        size_t end = line.find_first_of("\"'", start);
        return line.substr(start, end - start);
    }

    // --- 构建图 ---
    void buildGraph() {
        for (const auto& w : ways_) {
            // 对于每一条路，连接相邻的点
            // 如果 relation 标记为 Successor，保留为单向链路；否则双向连接
            bool is_successor = false;
            std::string lr = w.relation;
            std::transform(lr.begin(), lr.end(), lr.begin(), ::tolower);
            if (lr.find("successor") != std::string::npos) is_successor = true;
            for (size_t i = 0; i + 1 < w.node_refs.size(); ++i) {
                adjacency_list_[w.node_refs[i]].push_back(w.node_refs[i+1]);
                if (!is_successor) {
                    adjacency_list_[w.node_refs[i+1]].push_back(w.node_refs[i]);
                }
            }
        }
    }

    // --- 规划任务 ---
    void planTask() {
        if (nodes_map_.empty()) return;

        // Helper lambdas
        auto findWayById = [&](long long id) -> Way* {
            for (auto &w : ways_) if (w.id == id) return &w;
            return nullptr;
        };
        auto findRelationById = [&](long long id) -> Relation* {
            for (auto &r : relations_) if (r.id == id) return &r;
            return nullptr;
        };
        auto centroidOfWay = [&](const Way &w) -> std::pair<double,double> {
            double sx = 0, sy = 0; int c = 0;
            for (long long nid : w.node_refs) if (nodes_map_.count(nid)) { sx += nodes_map_[nid].x; sy += nodes_map_[nid].y; ++c; }
            if (c==0) return {0,0};
            return {sx/c, sy/c};
        };
        auto centroidOfRelation = [&](const Relation &r) -> std::pair<double,double> {
            double sx = 0, sy = 0; int c = 0;
            for (long long wid : r.member_way_refs) {
                Way* w = findWayById(wid);
                if (!w) continue;
                auto p = centroidOfWay(*w);
                sx += p.first; sy += p.second; ++c;
            }
            if (c==0) return {0,0};
            return {sx/c, sy/c};
        };

        // resample a way into N evenly spaced points (by index interpolation)
        auto resampleWayPoints = [&](Way* w, int N) {
            std::vector<std::pair<double,double>> out;
            if (!w || w->node_refs.empty()) return out;
            // collect original points
            std::vector<std::pair<double,double>> pts;
            for (long long nid : w->node_refs) if (nodes_map_.count(nid)) pts.emplace_back(nodes_map_[nid].x, nodes_map_[nid].y);
            if (pts.empty()) return out;
            if ((int)pts.size() == 1) { out.push_back(pts[0]); return out; }
            // cumulative lengths
            std::vector<double> d(pts.size(), 0.0);
            for (size_t i=1;i<pts.size();++i) {
                double dx = pts[i].first - pts[i-1].first; double dy = pts[i].second - pts[i-1].second; d[i] = d[i-1] + std::hypot(dx,dy);
            }
            double L = d.back();
            for (int k=0;k<N;++k) {
                double s = (L * k) / (N-1);
                // find segment
                size_t idx = 0;
                while (idx+1 < d.size() && d[idx+1] < s) ++idx;
                double segL = d[idx+1] - d[idx];
                double t = (segL > 1e-9) ? ((s - d[idx]) / segL) : 0.0;
                double x = pts[idx].first * (1-t) + pts[idx+1].first * t;
                double y = pts[idx].second * (1-t) + pts[idx+1].second * t;
                out.emplace_back(x,y);
            }
            return out;
        };

        // compute a centerline for a relation by averaging corresponding points of member ways
        auto computeRelationCenterline = [&](Relation* r) {
            std::vector<std::pair<double,double>> center;
            if (!r) return center;
            if (r->member_way_refs.empty()) return center;
            // pick first member as reference and resample all members to same N
            const int N = 40;
            std::vector<std::vector<std::pair<double,double>>> all_pts;
            for (long long wid : r->member_way_refs) {
                Way* w = findWayById(wid);
                if (!w) continue;
                auto pts = resampleWayPoints(w, N);
                if (!pts.empty()) all_pts.push_back(std::move(pts));
            }
            if (all_pts.empty()) return center;
            // ensure all have same length by trimming/padding
            size_t M = all_pts[0].size();
            for (auto &v : all_pts) if (v.size() != M) { /* ignore differing sizes for now */ }
            // average across members
            center.resize(M, {0.0,0.0});
            for (size_t i=0;i<M;++i) {
                double sx=0, sy=0; int c=0;
                for (auto &v : all_pts) { if (i < v.size()) { sx += v[i].first; sy += v[i].second; ++c; } }
                if (c>0) { center[i].first = sx / c; center[i].second = sy / c; }
            }
            return center;
        };

        auto findNearestAdjNode = [&](double x, double y) -> long long {
            long long best = -1; double bestd = 1e18;
            for (const auto &kv : adjacency_list_) {
                long long nid = kv.first;
                if (!nodes_map_.count(nid)) continue;
                double dx = nodes_map_[nid].x - x; double dy = nodes_map_[nid].y - y; double d = dx*dx + dy*dy;
                if (d < bestd) { bestd = d; best = nid; }
            }
            return best;
        };

        // IDs provided by user
    const long long PARK_LANELET_ID = 9265; // parking lanelet center (target)
    const long long LINESTR_ID_A = 9386; // linestring A
    const long long LINESTR_ID_B = 9392; // linestring B
    const long long START_LANELET_CENTER_ID = 9259; // start center lanelet

        // 1) Set initial vehicle pose to center of lanelet 106 if possible
        bool set_start_pose = false;
        Relation* start_rel = findRelationById(START_LANELET_CENTER_ID);
        std::vector<std::pair<double,double>> start_centerline;
        if (start_rel) {
            start_centerline = computeRelationCenterline(start_rel);
            if (!start_centerline.empty()) {
                // set start pose to centerline midpoint
                size_t mid = start_centerline.size()/2;
                car_.x = start_centerline[mid].first; car_.y = start_centerline[mid].second; set_start_pose = true;
                // derive heading from neighboring centerline points
                if (mid+1 < start_centerline.size()) car_.theta = std::atan2(start_centerline[mid+1].second - start_centerline[mid].second, start_centerline[mid+1].first - start_centerline[mid].first);
            } else {
                auto c = centroidOfRelation(*start_rel);
                car_.x = c.first; car_.y = c.second; set_start_pose = true;
            }
        } else {
            Way* start_way = findWayById(START_LANELET_CENTER_ID);
            if (start_way) { auto c = centroidOfWay(*start_way); car_.x = c.first; car_.y = c.second; set_start_pose = true; }
        }

        if (!set_start_pose) {
            ROS_WARN("Start lanelet %lld not found; using map center as start.", START_LANELET_CENTER_ID);
            // fallback to map center
            double minx = 1e18, miny = 1e18, maxx = -1e18, maxy = -1e18;
            for (const auto &kv : nodes_map_) { minx = std::min(minx, kv.second.x); miny = std::min(miny, kv.second.y); maxx = std::max(maxx, kv.second.x); maxy = std::max(maxy, kv.second.y); }
            car_.x = 0.5*(minx+maxx); car_.y = 0.5*(miny+maxy);
        }

    // 2) choose a start graph node id: prefer a node that belongs to the START_LANELET relation centerline
    // Note: the "start" concept exposed to the user is the lanelet centroid + heading (no id).
    long long start_node_id = -1;
        if (start_rel) {
            // find the member way nodes and pick the one closest to the relation centroid that is present in the adjacency graph
            auto rc = centroidOfRelation(*start_rel);
            double bestd = 1e18;
            for (long long wid : start_rel->member_way_refs) {
                Way* w = findWayById(wid);
                if (!w) continue;
                for (size_t i = 0; i < w->node_refs.size(); ++i) {
                    long long nid = w->node_refs[i];
                    if (!nodes_map_.count(nid)) continue;
                    // prefer nodes that appear in adjacency_list_ (i.e., graph nodes)
                    if (adjacency_list_.count(nid) == 0 && adjacency_list_.count(nid) == 0) {
                        // still consider, but deprioritize
                    }
                    double dx = nodes_map_[nid].x - rc.first; double dy = nodes_map_[nid].y - rc.second; double d = dx*dx + dy*dy;
                    if (d < bestd) { bestd = d; start_node_id = nid; }
                }
            }
            if (start_node_id != -1) {
                ROS_INFO("Start relation %lld -> selected start graph node id %lld (closest to relation centroid)", START_LANELET_CENTER_ID, start_node_id);
                // set car pose to the relation centroid and heading along the local centerline tangent
                car_.x = rc.first; car_.y = rc.second;
                // determine heading by finding a local tangent at the chosen node
                // locate which way/position this node belongs to and pick the neighboring node
                for (long long wid : start_rel->member_way_refs) {
                    Way* w = findWayById(wid); if (!w) continue;
                    for (size_t i = 0; i < w->node_refs.size(); ++i) {
                            if (w->node_refs[i] == start_node_id) {
                            long long n0 = start_node_id;
                            long long n1 = (i+1 < w->node_refs.size()) ? w->node_refs[i+1] : (i>0 ? w->node_refs[i-1] : w->node_refs[i]);
                            if (nodes_map_.count(n1)) {
                                double hvx = nodes_map_[n1].x - nodes_map_[n0].x;
                                double hvy = nodes_map_[n1].y - nodes_map_[n0].y;
                                car_.theta = std::atan2(hvy, hvx);
                            }
                        }
                    }
                }
            }
        }

        // fallback: if we still don't have a start graph node id, choose nearest adjacency node to the computed start pose
        if (start_node_id == -1) {
            start_node_id = findNearestAdjNode(car_.x, car_.y);
            if (start_node_id == -1) { for (const auto &kv : adjacency_list_) { start_node_id = kv.first; break; } }
        }

        // Debug: expose the start as lanelet centroid + heading (no id concept). Also log the internal graph node used.
        ROS_INFO("Start lanelet id %lld centroid at (%.3f, %.3f) heading=%.3f rad", START_LANELET_CENTER_ID, car_.x, car_.y, car_.theta);
        if (start_node_id != -1) {
            if (nodes_map_.count(start_node_id)) {
                ROS_INFO("Using internal start graph node id=%lld at (%.3f, %.3f)", start_node_id, nodes_map_[start_node_id].x, nodes_map_[start_node_id].y);
            } else {
                ROS_INFO("Using internal start graph node id=%lld (no coords available)", start_node_id);
            }
        }
        // find nearest relation (lanelet) centroid to the start pose for debugging
        long long nearest_rel = -1; double rel_bestd = 1e18;
        for (const auto &r : relations_) {
            auto rc = centroidOfRelation(r);
            double dx = rc.first - car_.x, dy = rc.second - car_.y;
            double d = dx*dx + dy*dy;
            if (d < rel_bestd) { rel_bestd = d; nearest_rel = r.id; }
        }
        if (nearest_rel != -1) {
            ROS_INFO("Nearest relation to start pose: id=%lld (centroid dist=%.3f m)", nearest_rel, std::sqrt(rel_bestd));
        }

        // 3) Compute target (parking) location: center of lanelet 9265 (relation or way)
        double target_cx = 0, target_cy = 0; bool have_target_center = false;
        Relation* park_rel = findRelationById(PARK_LANELET_ID);
        if (park_rel) { auto c = centroidOfRelation(*park_rel); target_cx = c.first; target_cy = c.second; have_target_center = true; }
        else { Way* park_way = findWayById(PARK_LANELET_ID); if (park_way) { auto c = centroidOfWay(*park_way); target_cx = c.first; target_cy = c.second; have_target_center = true; } }

        if (!have_target_center) {
            ROS_WARN("Target lanelet %lld not found; aborting planning.", PARK_LANELET_ID);
            return;
        }

        // 4) Compute parking target area between the two linestrings (ways) by finding closest points
        double park_x = target_cx, park_y = target_cy;
        Way* wa = findWayById(LINESTR_ID_A);
        Way* wb = findWayById(LINESTR_ID_B);

        std::vector<std::pair<double,double>> park_centerline;
        if (park_rel) {
            park_centerline = computeRelationCenterline(park_rel);
            if (!park_centerline.empty()) {
                size_t mid = park_centerline.size()/2;
                park_x = park_centerline[mid].first; park_y = park_centerline[mid].second;
                // ensure target_theta aligns with centerline tangent if available
                if (mid+1 < park_centerline.size()) {
                    double cx = park_centerline[mid+1].first - park_centerline[mid].first;
                    double cy = park_centerline[mid+1].second - park_centerline[mid].second;
                    double cang = std::atan2(cy, cx);
                    // perpendicular into parking area will be computed later relative to cang
                }
            }
        }

        // helper: project point p onto segment a-b, returning closest point
        auto projectOntoSegment = [&](const std::pair<double,double>& a, const std::pair<double,double>& b, const std::pair<double,double>& p) {
            double ax = a.first, ay = a.second, bx = b.first, by = b.second, px = p.first, py = p.second;
            double vx = bx-ax, vy = by-ay;
            double wx = px-ax, wy = py-ay;
            double vv = vx*vx + vy*vy;
            double t = (vv > 0) ? (vx*wx + vy*wy) / vv : 0.0;
            if (t < 0) t = 0; if (t > 1) t = 1;
            return std::make_pair(ax + t*vx, ay + t*vy);
        };

        bool haveA=false, haveB=false;
        std::pair<double,double> bestA, bestB;
        double bestDist = 1e18;

        if (wa && wb) {
            // iterate nodes of wa and segments of wb
            for (size_t i=0;i<wa->node_refs.size();++i) {
                if (!nodes_map_.count(wa->node_refs[i])) continue;
                auto pA = std::make_pair(nodes_map_[wa->node_refs[i]].x, nodes_map_[wa->node_refs[i]].y);
                for (size_t j=0;j+1<wb->node_refs.size();++j) {
                    if (!nodes_map_.count(wb->node_refs[j]) || !nodes_map_.count(wb->node_refs[j+1])) continue;
                    auto b0 = std::make_pair(nodes_map_[wb->node_refs[j]].x, nodes_map_[wb->node_refs[j]].y);
                    auto b1 = std::make_pair(nodes_map_[wb->node_refs[j+1]].x, nodes_map_[wb->node_refs[j+1]].y);
                    auto proj = projectOntoSegment(b0,b1,pA);
                    double dx = pA.first - proj.first, dy = pA.second - proj.second;
                    double d = dx*dx + dy*dy;
                    if (d < bestDist) { bestDist = d; bestA = pA; bestB = proj; haveA=true; haveB=true; }
                }
            }
            // also try nodes of wb against segments of wa
            for (size_t i=0;i<wb->node_refs.size();++i) {
                if (!nodes_map_.count(wb->node_refs[i])) continue;
                auto pB = std::make_pair(nodes_map_[wb->node_refs[i]].x, nodes_map_[wb->node_refs[i]].y);
                for (size_t j=0;j+1<wa->node_refs.size();++j) {
                    if (!nodes_map_.count(wa->node_refs[j]) || !nodes_map_.count(wa->node_refs[j+1])) continue;
                    auto a0 = std::make_pair(nodes_map_[wa->node_refs[j]].x, nodes_map_[wa->node_refs[j]].y);
                    auto a1 = std::make_pair(nodes_map_[wa->node_refs[j+1]].x, nodes_map_[wa->node_refs[j+1]].y);
                    auto proj = projectOntoSegment(a0,a1,pB);
                    double dx = pB.first - proj.first, dy = pB.second - proj.second;
                    double d = dx*dx + dy*dy;
                    if (d < bestDist) { bestDist = d; bestA = proj; bestB = pB; haveA=true; haveB=true; }
                }
            }
        }

        if (haveA && haveB) {
            park_x = 0.5*(bestA.first + bestB.first);
            park_y = 0.5*(bestA.second + bestB.second);
        }

        // 5) Determine orientation: perpendicular (90 deg) to the lanelet centerline at target, pointing into the parking area
        double target_theta = 0.0;
        Way* centerline_way = nullptr;
        if (park_rel && !park_rel->member_way_refs.empty()) centerline_way = findWayById(park_rel->member_way_refs[0]);
        if (!centerline_way) centerline_way = findWayById(PARK_LANELET_ID);
        // compute a tangent vector t at the nearest point on centerline to park center
        double tx = 1.0, ty = 0.0; // default
        if (centerline_way && centerline_way->node_refs.size() >= 2) {
            int idx_best = -1; double bestd = 1e18;
            for (size_t i=0;i<centerline_way->node_refs.size();++i) {
                long long nid = centerline_way->node_refs[i]; if (!nodes_map_.count(nid)) continue;
                double dx = nodes_map_[nid].x - park_x; double dy = nodes_map_[nid].y - park_y; double d = dx*dx+dy*dy;
                if (d < bestd) { bestd = d; idx_best = i; }
            }
            if (idx_best != -1) {
                long long n0 = centerline_way->node_refs[idx_best];
                long long n1 = (idx_best+1 < (int)centerline_way->node_refs.size()) ? centerline_way->node_refs[idx_best+1] : centerline_way->node_refs[idx_best>0?idx_best-1:idx_best];
                if (nodes_map_.count(n0) && nodes_map_.count(n1)) {
                    tx = nodes_map_[n1].x - nodes_map_[n0].x;
                    ty = nodes_map_[n1].y - nodes_map_[n0].y;
                    double norm = std::hypot(tx,ty); if (norm>0){ tx/=norm; ty/=norm; }
                }
            }
        }
        // perpendicular to t
        double perp_x = -ty, perp_y = tx;
        // decide sign so perpendicular points toward parking center from centerline
        double cx = 0, cy = 0;
        if (centerline_way && !centerline_way->node_refs.empty() && nodes_map_.count(centerline_way->node_refs[0])) { cx = nodes_map_[centerline_way->node_refs[0]].x; cy = nodes_map_[centerline_way->node_refs[0]].y; }
        double side = ( (tx)*(park_y - cy) - (ty)*(park_x - cx) );
        if (side < 0) { perp_x = -perp_x; perp_y = -perp_y; }
    target_theta = std::atan2(perp_y, perp_x);
    // store for use by the parking maneuver
    parking_target_theta_ = target_theta;

        // visualize the parking patch as a small rectangular polygon between bestA and bestB
        if (haveA && haveB) {
            double dx = bestB.first - bestA.first; double dy = bestB.second - bestA.second; double gap = std::hypot(dx,dy);
            double seg_len = std::min(6.0, std::max(2.0, gap)); // length of polygon along the lines
            // direction along centerline for extending the ends
            double ex = tx, ey = ty;
            // compute four corners
            std::vector<std::pair<double,double>> corners;
            auto make_pt = [&](double cx, double cy, double ox, double oy){ return std::make_pair(cx + ox, cy + oy); };
            // endpoints on A and B extended along centerline
            auto a1 = make_pt(bestA.first, bestA.second, -0.5*seg_len*ex, -0.5*seg_len*ey);
            auto a2 = make_pt(bestA.first, bestA.second,  0.5*seg_len*ex,  0.5*seg_len*ey);
            auto b1 = make_pt(bestB.first, bestB.second, -0.5*seg_len*ex, -0.5*seg_len*ey);
            auto b2 = make_pt(bestB.first, bestB.second,  0.5*seg_len*ex,  0.5*seg_len*ey);
            corners.push_back(a1); corners.push_back(a2); corners.push_back(b2); corners.push_back(b1);

            visualization_msgs::Marker mark;
            mark.header.frame_id = "map";
            mark.header.stamp = ros::Time::now();
            mark.ns = "selected_parking_area";
            mark.id = 0;
            mark.type = visualization_msgs::Marker::LINE_STRIP;
            mark.scale.x = 0.12;
            mark.color.a = 0.9; mark.color.r = 0.0; mark.color.g = 1.0; mark.color.b = 0.0;
            for (auto &c : corners) { geometry_msgs::Point gp; gp.x = c.first; gp.y = c.second; gp.z = 0.02; mark.points.push_back(gp); }
            // close
            geometry_msgs::Point gp0; gp0.x = corners[0].first; gp0.y = corners[0].second; gp0.z = 0.02; mark.points.push_back(gp0);
            visualization_msgs::MarkerArray arr; arr.markers.push_back(mark);
            // publish selected parking area using the parking_spots topic (parking area outlines)
            parking_pub_.publish(arr);

            // Additionally, highlight the exact parking slot nodes if present (user-provided IDs)
            std::vector<long long> target_nodes = {9385, 9384, 9390, 9391};
            bool have_all = true;
            for (long long nid : target_nodes) if (!nodes_map_.count(nid)) { have_all = false; break; }
            if (have_all) {
                visualization_msgs::Marker slot_m;
                slot_m.header.frame_id = "map";
                slot_m.header.stamp = ros::Time::now();
                slot_m.ns = "target_parking_slot";
                slot_m.id = 1;
                slot_m.type = visualization_msgs::Marker::LINE_STRIP;
                slot_m.scale.x = 0.14;
                slot_m.color.a = 0.95; slot_m.color.r = 0.0; slot_m.color.g = 0.2; slot_m.color.b = 1.0; // blue
                for (long long nid : target_nodes) {
                    geometry_msgs::Point pp; pp.x = nodes_map_[nid].x; pp.y = nodes_map_[nid].y; pp.z = 0.03; slot_m.points.push_back(pp);
                }
                // close polygon
                geometry_msgs::Point p0; p0.x = nodes_map_[target_nodes[0]].x; p0.y = nodes_map_[target_nodes[0]].y; p0.z = 0.03; slot_m.points.push_back(p0);
                visualization_msgs::MarkerArray marr; marr.markers.push_back(slot_m);
                parking_pub_.publish(marr);
                ROS_INFO("Highlighted target parking slot nodes: %lld,%lld,%lld,%lld", target_nodes[0], target_nodes[1], target_nodes[2], target_nodes[3]);
            } else {
                ROS_WARN("Target parking slot nodes missing in map; cannot highlight exact slot.");
            }
        }

        // 6) Plan graph path: prefer a node that belongs to the PARK_LANELET relation centerline
        long long target_node = -1;
    if (park_rel) {
            double bestd = 1e18;
            for (long long wid : park_rel->member_way_refs) {
                Way* w = findWayById(wid);
                if (!w) continue;
                for (long long nid : w->node_refs) {
                    if (!nodes_map_.count(nid)) continue;
                    double dx = nodes_map_[nid].x - park_x; double dy = nodes_map_[nid].y - park_y; double d = dx*dx + dy*dy;
                    if (d < bestd) { bestd = d; target_node = nid; }
                }
            }
        }
    if (target_node == -1) target_node = findNearestAdjNode(park_x, park_y);

    std::vector<long long> path_ids;
    if (start_node_id != -1 && target_node != -1) path_ids = bfs(start_node_id, target_node);

    ROS_INFO("Planning request: start_node=%lld target_node=%lld", start_node_id, target_node);
        if (!path_ids.empty()) {
            std::stringstream ss; for (size_t i=0;i<path_ids.size();++i) { if (i) ss << "->"; ss << path_ids[i]; }
            ROS_INFO("Planned path node sequence: %s", ss.str().c_str());
        }

        if (path_ids.empty()) {
            ROS_WARN("No path found from start_node %lld to target node %lld; falling back to straight approach near target.", start_node_id, target_node);
            // extra diagnostics: print nearby adjacency nodes count
            int adj_count = adjacency_list_.count(start_node_id) ? adjacency_list_[start_node_id].size() : 0;
            ROS_INFO("Start node %lld has %d adjacent neighbours in adjacency_list_.", start_node_id, adj_count);
            if (nodes_map_.count(start_node_id)) ROS_INFO("Start node coords (%.3f, %.3f)", nodes_map_[start_node_id].x, nodes_map_[start_node_id].y);
            // simple straight approach to target location
            car_.theta = target_theta;
            for (int i=0;i<200;i++) { CarState s; s.x = car_.x + i*0.1*cos(car_.theta); s.y = car_.y + i*0.1*sin(car_.theta); s.theta = car_.theta; s.v = 1.0; global_plan_.push_back(s); }
        } else {
            for (long long id : path_ids) { CarState s; s.x = nodes_map_[id].x; s.y = nodes_map_[id].y; s.v = std::min(1.5, max_speed_); global_plan_.push_back(s); }
            // append a smooth local approach to a standoff point before the parking center, then align perpendicular
            CarState last = global_plan_.back();
            // standoff distance from parking center (meters)
            double standoff = 2.0;
            double st_x = park_x - perp_x * standoff;
            double st_y = park_y - perp_y * standoff;

            // build a cubic Hermite (smooth) between last and standoff
            double x0 = last.x, y0 = last.y;
            double x1 = st_x, y1 = st_y;
            double dx = x1 - x0, dy = y1 - y0;
            double L = std::hypot(dx, dy);
            int approach_steps = std::max(10, static_cast<int>(std::min(60.0, L * 5.0)));

            // tangent directions: m0 along last heading, m1 along target approach direction (toward standoff)
            double v0x = 1.0, v0y = 0.0;
            if (global_plan_.size() > 1) {
                CarState prev = global_plan_[std::max(0, (int)global_plan_.size()-2)];
                double hvx = last.x - prev.x, hvy = last.y - prev.y; double hnorm = std::hypot(hvx,hvy);
                if (hnorm > 1e-6) { v0x = hvx / hnorm; v0y = hvy / hnorm; }
            }
            double v1x = (x1 - x0) / (L>1e-6?L:1.0);
            double v1y = (y1 - y0) / (L>1e-6?L:1.0);

            // derivative magnitudes scaled by distance
            double mscale = L * 0.5;
            double m0x = v0x * mscale, m0y = v0y * mscale;
            double m1x = v1x * mscale, m1y = v1y * mscale;

            for (int i=1;i<=approach_steps;i++) {
                double t = double(i) / approach_steps;
                double t2 = t*t, t3 = t2*t;
                double h00 =  2*t3 - 3*t2 + 1;
                double h10 =      t3 - 2*t2 + t;
                double h01 = -2*t3 + 3*t2;
                double h11 =      t3 -   t2;
                double px = h00*x0 + h10*m0x + h01*x1 + h11*m1x;
                double py = h00*y0 + h10*m0y + h01*y1 + h11*m1y;
                CarState s; s.x = px; s.y = py; s.theta = std::atan2(v1y, v1x); s.v = std::min(0.8, max_speed_); global_plan_.push_back(s);
            }

            // final approach: move from standoff to exact park center aligned perpendicular (90 deg)
            int final_steps = 10;
            for (int i=1;i<=final_steps;i++) {
                double t = double(i) / final_steps;
                CarState s;
                s.x = st_x*(1-t) + park_x*t;
                s.y = st_y*(1-t) + park_y*t;
                s.theta = target_theta;
                s.v = std::min(0.4, max_speed_);
                global_plan_.push_back(s);
            }
            car_.x = global_plan_[0].x; car_.y = global_plan_[0].y; if (global_plan_.size()>1) car_.theta = std::atan2(global_plan_[1].y-global_plan_[0].y, global_plan_[1].x-global_plan_[0].x);
        }

        // 7) At the parking target orientation is target_theta; align before adding parking maneuver
        // Ensure the final point has target_theta
        if (!global_plan_.empty()) { global_plan_.back().theta = target_theta; }

        addParkingManeuver();
    }

    std::vector<long long> bfs(long long start, long long goal) {
        std::queue<long long> q;
        std::map<long long, long long> came_from;
        q.push(start);
        came_from[start] = start;

        while (!q.empty()) {
            long long current = q.front();
            q.pop();

            if (current == goal) break;

            for (long long next : adjacency_list_[current]) {
                if (came_from.find(next) == came_from.end()) {
                    q.push(next);
                    came_from[next] = current;
                }
            }
        }

        std::vector<long long> path;
        if (came_from.find(goal) == came_from.end()) return path; // 未找到
        long long curr = goal;
        while (curr != start) {
            path.push_back(curr);
            curr = came_from[curr];
        }
        path.push_back(start);
        std::reverse(path.begin(), path.end());
        return path;
    }

    // --- 添加泊车轨迹 (几何生成) ---
    void addParkingManeuver() {
        if (global_plan_.empty()) return;
        // Controlled parking maneuver that rotates vehicle to the planned perpendicular orientation
        CarState end_point = global_plan_.back();
        double dt = 0.1;
        double current_yaw = (global_plan_.size() > 1) ?
            std::atan2(end_point.y - global_plan_[global_plan_.size()-2].y, end_point.x - global_plan_[global_plan_.size()-2].x) : 0;

        CarState s = end_point;
        s.theta = current_yaw;

        // 1) Small forward alignment (shorter, configurable)
        for (int i = 0; i < 30; ++i) {
            s.x += 0.5 * cos(s.theta) * dt;
            s.y += 0.5 * sin(s.theta) * dt;
            s.v = 0.6;
            global_plan_.push_back(s);
        }

        // 2) Rotate toward parking_target_theta_ while reversing into the slot.
        // Compute angular difference and perform incremental steps to reach exactly 90deg alignment.
        auto normalizeAng = [](double a){ while (a > M_PI) a -= 2*M_PI; while (a <= -M_PI) a += 2*M_PI; return a; };
        double desired = parking_target_theta_;
        double cur = s.theta;
        double diff = normalizeAng(desired - cur);

        // choose angular step size (rad) per control step
        double ang_step = 0.02; // ~1.15 deg per step
        int steps = std::max(1, static_cast<int>(std::ceil(std::abs(diff) / ang_step)));
        double step_ang = diff / steps;

        // reversing speed magnitude
        double rev_speed = -0.4;
        // steering indicator: sign toward rotation direction
        double steer_phi = (step_ang < 0) ? -0.6 : 0.6;

        for (int i = 0; i < steps; ++i) {
            s.theta = normalizeAng(s.theta + step_ang);
            s.x += rev_speed * cos(s.theta) * dt;
            s.y += rev_speed * sin(s.theta) * dt;
            s.v = rev_speed;
            s.phi = steer_phi;
            global_plan_.push_back(s);
        }

        // ensure final heading matches desired exactly
        s.theta = desired;

        // 3) small reverse settle forward/back as needed (move slightly to center)
        for (int i = 0; i < 10; ++i) {
            s.x += rev_speed * cos(s.theta) * dt;
            s.y += rev_speed * sin(s.theta) * dt;
            s.v = rev_speed;
            s.phi = 0.0;
            global_plan_.push_back(s);
        }
    }

    // --- 控制与仿真循环 ---
    void controlLoop(const ros::TimerEvent&) {
        if (current_idx_ >= static_cast<int>(global_plan_.size())) {
            // 任务结束，发布最后的姿态
            publishPose();
            return;
        }

        // 简单的 "Teleport" 仿真，实际应使用 PID 追踪 global_plan_[current_idx_]
        car_ = global_plan_[current_idx_];
        current_idx_++;

        // 1. 发布路径 (Visual)
        nav_msgs::Path path_msg;
        path_msg.header.frame_id = "map";
        path_msg.header.stamp = ros::Time::now();
        for (const auto& p : global_plan_) {
            geometry_msgs::PoseStamped ps;
            ps.pose.position.x = p.x;
            ps.pose.position.y = p.y;
            ps.pose.orientation = tf::createQuaternionMsgFromYaw(p.theta);
            path_msg.poses.push_back(ps);
        }
        path_pub_.publish(path_msg);

        // 2. 发布车辆姿态
        publishPose();
    }

    void publishPose() {
        // TF
        static tf::TransformBroadcaster br;
        tf::Transform transform;
        transform.setOrigin(tf::Vector3(car_.x, car_.y, 0.0));
        tf::Quaternion q;
        q.setRPY(0, 0, car_.theta);
        transform.setRotation(q);
        br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "map", "base_link"));

        // Pose2D
        geometry_msgs::Pose2D p2d;
        p2d.x = car_.x;
        p2d.y = car_.y;
        p2d.theta = car_.theta;
        pose_pub_.publish(p2d);

    // Marker Car (publish to dedicated car topic)
    visualization_msgs::MarkerArray car_marker;
    visualization_msgs::Marker m;
        m.header.frame_id = "map";
        m.header.stamp = ros::Time::now();
        m.ns = "car_body";
        m.id = 0;
        m.type = visualization_msgs::Marker::CUBE;
        m.pose.position.x = car_.x;
        m.pose.position.y = car_.y;
        m.pose.position.z = 0.5;
        m.pose.orientation = tf::createQuaternionMsgFromYaw(car_.theta);
        m.scale.x = 3.5;
        m.scale.y = 1.6;
        m.scale.z = 1.0;
        m.color.a = 0.8;
        m.color.b = 1.0;
        car_marker.markers.push_back(m);
        car_pub_.publish(car_marker);
    }

    // --- 可视化地图 ---
    void publishMap() {
        // Publish ways separately (LINE_LIST)
        visualization_msgs::MarkerArray ways_arr;
        visualization_msgs::Marker ways_marker;
        ways_marker.header.frame_id = "map";
        ways_marker.header.stamp = ros::Time::now();
        ways_marker.ns = "lanelet_ways";
        ways_marker.type = visualization_msgs::Marker::LINE_LIST;
        ways_marker.scale.x = 0.1;
        ways_marker.color.a = 0.6;
        ways_marker.color.r = 1.0;
        ways_marker.color.g = 1.0;
        ways_marker.color.b = 1.0; // 白色道路
        ways_marker.id = 0;

        for (const auto& w : ways_) {
            for (size_t i = 0; i + 1 < w.node_refs.size(); ++i) {
                long long id1 = w.node_refs[i];
                long long id2 = w.node_refs[i+1];
                if (nodes_map_.count(id1) && nodes_map_.count(id2)) {
                    geometry_msgs::Point p1, p2;
                    p1.x = nodes_map_[id1].x;
                    p1.y = nodes_map_[id1].y;
                    p1.z = 0.0;
                    p2.x = nodes_map_[id2].x;
                    p2.y = nodes_map_[id2].y;
                    p2.z = 0.0;
                    ways_marker.points.push_back(p1);
                    ways_marker.points.push_back(p2);
                }
            }
        }
        ways_arr.markers.push_back(ways_marker);
        ways_pub_.publish(ways_arr);

        // Publish relations (each member way rendered as LINE_STRIP under the relation namespace)
        visualization_msgs::MarkerArray rels_arr;
        int rel_id = 0;
        for (const auto& r : relations_) {
            visualization_msgs::Marker rel_marker;
            rel_marker.header.frame_id = "map";
            rel_marker.header.stamp = ros::Time::now();
            rel_marker.ns = std::string("relation_") + std::to_string(r.id);
            rel_marker.type = visualization_msgs::Marker::LINE_STRIP;
            rel_marker.scale.x = 0.15;
            rel_marker.color.a = 0.7;
            rel_marker.color.r = 1.0;
            rel_marker.color.g = 0.0;
            rel_marker.color.b = 1.0; // magenta for relation boundaries
            rel_marker.id = rel_id++;

            // concatenate member way geometries (may create disconnected strips)
            for (long long way_id : r.member_way_refs) {
                for (const auto& w : ways_) {
                    if (w.id == way_id) {
                        for (size_t i = 0; i < w.node_refs.size(); ++i) {
                            long long nid = w.node_refs[i];
                            if (nodes_map_.count(nid)) {
                                geometry_msgs::Point p;
                                p.x = nodes_map_[nid].x;
                                p.y = nodes_map_[nid].y;
                                p.z = 0.0;
                                rel_marker.points.push_back(p);
                            }
                        }
                        break;
                    }
                }
                // insert a small break by repeating an empty point? not necessary for LINE_STRIP
            }
            rels_arr.markers.push_back(rel_marker);
        }
        relations_pub_.publish(rels_arr);

    // Publish nodes as small spheres (optional)
        visualization_msgs::MarkerArray nodes_arr;
        int nid_idx = 0;
        for (const auto& kv : nodes_map_) {
            visualization_msgs::Marker m;
            m.header.frame_id = "map";
            m.header.stamp = ros::Time::now();
            m.ns = "osm_nodes";
            m.id = nid_idx++;
            m.type = visualization_msgs::Marker::SPHERE;
            m.pose.position.x = kv.second.x;
            m.pose.position.y = kv.second.y;
            m.pose.position.z = 0.0;
            m.scale.x = 0.2;
            m.scale.y = 0.2;
            m.scale.z = 0.2;
            m.color.a = 0.4;
            m.color.r = 1.0;
            m.color.g = 1.0;
            m.color.b = 0.0;
            nodes_arr.markers.push_back(m);
        }
        nodes_pub_.publish(nodes_arr);

        // Compute parking spot coordinates (projected) for way-based spots and ensure node-based spots have coords
        for (auto &ps : parking_spots_) {
            if (ps.from_way) {
                // find way
                for (const auto &w : ways_) {
                    if (w.id == ps.id) {
                        double sx = 0, sy = 0; int cnt = 0;
                        for (long long nid : w.node_refs) {
                            if (nodes_map_.count(nid)) {
                                sx += nodes_map_[nid].x;
                                sy += nodes_map_[nid].y;
                                ++cnt;
                            }
                        }
                        if (cnt > 0) { ps.x = sx / cnt; ps.y = sy / cnt; }
                        break;
                    }
                }
            } else {
                if (nodes_map_.count(ps.id)) {
                    ps.x = nodes_map_[ps.id].x;
                    ps.y = nodes_map_[ps.id].y;
                }
            }
        }

        // Publish parking areas: pair nearby parking-space ways into rectangular slots
        visualization_msgs::MarkerArray park_arr;
        int pid = 0;

        // build quick lookup for ways by id
        std::map<long long, Way*> way_by_id;
        for (auto &w : ways_) way_by_id[w.id] = &w;

        // collect candidate parking ways: either explicitly tagged or referenced in parking_spots_
        std::vector<Way*> park_ways;
        for (auto &w : ways_) {
            std::string wt = w.wtype;
            std::transform(wt.begin(), wt.end(), wt.begin(), ::tolower);
            bool is_parking_tag = (wt == "parking_space");
            if (!is_parking_tag) {
                for (const auto &ps : parking_spots_) { if (ps.from_way && ps.id == w.id) { is_parking_tag = true; break; } }
            }
            if (is_parking_tag) park_ways.push_back(&w);
        }

        std::set<long long> used;
        auto way_centroid = [&](Way* w) {
            double sx=0, sy=0; int c=0;
            for (long long nid : w->node_refs) if (nodes_map_.count(nid)) { sx += nodes_map_[nid].x; sy += nodes_map_[nid].y; ++c; }
            if (c==0) return std::make_pair(0.0,0.0);
            return std::make_pair(sx/c, sy/c);
        };

        for (size_t i=0;i<park_ways.size();++i) {
            Way* a = park_ways[i]; if (!a) continue; if (used.count(a->id)) continue;
            // find nearest other parking way
            double bestd = 1e18; Way* best = nullptr;
            auto ca = way_centroid(a);
            for (size_t j=i+1;j<park_ways.size();++j) {
                Way* b = park_ways[j]; if (!b) continue; if (used.count(b->id)) continue;
                auto cb = way_centroid(b);
                double dx = ca.first - cb.first, dy = ca.second - cb.second; double d = dx*dx + dy*dy;
                if (d < bestd) { bestd = d; best = b; }
            }

            if (best && bestd < 50.0*50.0) { // pair if within 50m
                // form rectangle corners using endpoints of the two ways
                if (a->node_refs.size() >= 1 && best->node_refs.size() >= 1) {
                    // pick endpoints
                    long long a0 = a->node_refs.front(); long long a1 = a->node_refs.back();
                    long long b0 = best->node_refs.front(); long long b1 = best->node_refs.back();
                    if (nodes_map_.count(a0) && nodes_map_.count(a1) && nodes_map_.count(b0) && nodes_map_.count(b1)) {
                        visualization_msgs::Marker mk;
                        mk.header.frame_id = "map";
                        mk.header.stamp = ros::Time::now();
                        mk.ns = "parking_spot_area";
                        mk.id = pid++;
                        mk.type = visualization_msgs::Marker::LINE_STRIP;
                        mk.scale.x = 0.12;
                        mk.color.a = 0.9; mk.color.r = 0.0; mk.color.g = 0.8; mk.color.b = 0.0;

                        geometry_msgs::Point p_a0, p_a1, p_b1, p_b0;
                        p_a0.x = nodes_map_[a0].x; p_a0.y = nodes_map_[a0].y; p_a0.z = 0.02;
                        p_a1.x = nodes_map_[a1].x; p_a1.y = nodes_map_[a1].y; p_a1.z = 0.02;
                        p_b1.x = nodes_map_[b1].x; p_b1.y = nodes_map_[b1].y; p_b1.z = 0.02;
                        p_b0.x = nodes_map_[b0].x; p_b0.y = nodes_map_[b0].y; p_b0.z = 0.02;

                        mk.points.push_back(p_a0);
                        mk.points.push_back(p_a1);
                        mk.points.push_back(p_b1);
                        mk.points.push_back(p_b0);
                        // close
                        mk.points.push_back(p_a0);
                        park_arr.markers.push_back(mk);
                    }
                }
                used.insert(a->id); used.insert(best->id);
            } else {
                // single parking way: show as small cube at centroid
                auto c = ca;
                visualization_msgs::Marker m;
                m.header.frame_id = "map"; m.header.stamp = ros::Time::now(); m.ns = "parking_spots"; m.id = pid++;
                m.type = visualization_msgs::Marker::CUBE;
                m.pose.position.x = c.first; m.pose.position.y = c.second; m.pose.position.z = 0.05;
                m.scale.x = 2.5; m.scale.y = 1.25; m.scale.z = 0.1;
                m.color.a = 0.6; m.color.g = 1.0; m.color.r = 0.0; m.color.b = 0.0;
                park_arr.markers.push_back(m);
                used.insert(a->id);
            }
        }

        parking_pub_.publish(park_arr);

        // legacy aggregated map publish removed (use /parking_spots and /parking_blocks topics)
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "real_map_parking_node");
    ParkingSystem ps;
    ros::spin();
    return 0;
}
