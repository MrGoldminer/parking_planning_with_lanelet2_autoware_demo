#include <ros/ros.h>
#include <ros/package.h>
#include <visualization_msgs/MarkerArray.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/Twist.h>
#include <tf/transform_broadcaster.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <cmath>
#include <random>
#include <algorithm>
#include <queue>
#include <tuple>

// ================= 基础结构定义 =================
struct NodePoint {
    long long id;
    double lat, lon;
    double x, y; // 局部坐标
};

struct Way {
    long long id;
    std::vector<long long> node_refs;
    std::string wtype; 
};

struct Relation {
    long long id;
    std::vector<long long> member_way_refs;
    std::string type; 
};

// ================= 状态机与配置 =================
enum ScenarioStage {
    STAGE_IDLE,                 // 待机/寻找起点
    STAGE_APPROACHING,          // 阶段1：导航至 Apollo 泊车起始点 (9259)
    STAGE_PARKING,              // 阶段2：倒车入库 (不压 9386/9392)
    STAGE_FINISHED              // 完成
};

struct BestParkingSpaceConfig {
    double parking_spot_range_to_start = 20.0; 
    double max_valid_stop_distance = 0.5;      
    double parking_speed = 0.3;                
    double approach_speed = 1.0;
    double safety_margin = 0.1; // 距离车位线的安全距离
};

// ================= 数学工具 =================
class MapTools {
public:
    static double origin_lat_, origin_lon_;
    static void projectToLocal(std::map<long long, NodePoint>& nodes) {
        if (nodes.empty()) return;
        auto it = nodes.begin();
        origin_lat_ = it->second.lat; origin_lon_ = it->second.lon;
        double R = 6378137.0; 
        for (auto& pair : nodes) {
            double dlat = pair.second.lat - origin_lat_;
            double dlon = pair.second.lon - origin_lon_;
            double lat_rad = origin_lat_ * M_PI / 180.0;
            pair.second.x = R * (dlon * M_PI / 180.0) * cos(lat_rad);
            pair.second.y = R * (dlat * M_PI / 180.0);
        }
    }
    static double normalizeAng(double a){ while (a > M_PI) a -= 2*M_PI; while (a <= -M_PI) a += 2*M_PI; return a; }
    
    // 点到线段的最短距离
    static double distToSegment(double px, double py, double x1, double y1, double x2, double y2) {
        double C = (x2 - x1) * (px - x1) + (y2 - y1) * (py - y1);
        double D = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
        double param = -1.0;
        if (D != 0) param = C / D;
        double xx, yy;
        if (param < 0) { xx = x1; yy = y1; }
        else if (param > 1) { xx = x2; yy = y2; }
        else { xx = x1 + param * (x2 - x1); yy = y1 + param * (y2 - y1); }
        return std::hypot(px - xx, py - yy);
    }
};
double MapTools::origin_lat_ = 0.0;
double MapTools::origin_lon_ = 0.0;

// ================= 主节点类 =================
class ParkingSystem {
private:
    ros::NodeHandle nh_;
    ros::Publisher car_pub_, path_pub_, pose_pub_, ways_pub_, relations_pub_, nodes_pub_, parking_pub_, cmd_pub_, debug_pub_;
    ros::Timer loop_timer_;

    std::map<long long, NodePoint> nodes_map_;
    std::vector<Way> ways_;
    std::vector<Relation> relations_;
    std::map<long long, std::vector<long long>> adjacency_list_;

    struct CarState {
        double x = 0.0, y = 0.0, theta = 0.0;
        double v = 0.0, phi = 0.0;
    } car_;

    // 关键点坐标
    double parking_target_x_ = 0.0;
    double parking_target_y_ = 0.0;
    double parking_target_theta_ = 0.0;
    
    double pre_stop_x_ = 0.0;
    double pre_stop_y_ = 0.0;
    double pre_stop_theta_ = 0.0; // 9259 的方向

    // 车位边界线 (用于碰撞检测)
    std::vector<std::pair<double, double>> slot_line_a_; // 9386
    std::vector<std::pair<double, double>> slot_line_b_; // 9392

    // 车辆参数
    double wheelbase_ = 2.7;
    double max_steering_rad_ = 0.6;
    double vehicle_width_ = 1.85;
    double vehicle_length_ = 4.6;

    std::vector<CarState> global_plan_;
    int current_idx_ = 0;
    
    ScenarioStage current_stage_ = STAGE_IDLE;
    BestParkingSpaceConfig config_;
    bool map_loaded_ = false;
    bool mission_ready_ = false;
    bool parking_trajectory_generated_ = false;
    int gear_shift_counter_ = 0;

    // ============ 用户指定的 ID ============
    const long long PARK_LANELET_ID = 9265;         // 泊车区域 Relation (可选)
    const long long START_LANELET_CENTER_ID = 9259; // Apollo Pre-Stop Point (泊车起始点)
    const long long LINESTR_ID_A = 9386;            // 车位左边界
    const long long LINESTR_ID_B = 9392;            // 车位右边界

public:
    ParkingSystem() {
        car_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/car_marker", 10, false);
        ways_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/osm/ways", 1, true);
        relations_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/osm/relations", 1, true);
        nodes_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/osm/nodes", 1, true);
        parking_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/parking_spots", 1, true);
        path_pub_ = nh_.advertise<nav_msgs::Path>("/planned_path", 1, true);
        pose_pub_ = nh_.advertise<geometry_msgs::Pose2D>("/pose2d", 10);
        cmd_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
        debug_pub_ = nh_.advertise<visualization_msgs::Marker>("/debug_marker", 10);

        nh_.param("parking_spot_range_to_start", config_.parking_spot_range_to_start, 20.0);
        
        std::string path = ros::package::getPath("parking_demo") + "/maps/parking_map.osm";
        if (loadMap(path)) {
            MapTools::projectToLocal(nodes_map_);
            buildGraph();
            publishMap();
            map_loaded_ = true;
            
            // 初始化任务：计算 9259 和 9386/9392 的几何信息
            if(initMissionParams()) {
                mission_ready_ = true;
                // 为了演示，将车瞬移到起点附近
                long long start_node = findNearestAdjNode(pre_stop_x_, pre_stop_y_);
                if(start_node != -1) {
                    // 放到起点后方 15 米处，方便观察 APPROACHING 阶段
                    double dx = cos(pre_stop_theta_); double dy = sin(pre_stop_theta_);
                    car_.x = pre_stop_x_ - 15.0 * dx;
                    car_.y = pre_stop_y_ - 15.0 * dy;
                    car_.theta = pre_stop_theta_;
                }
            }
        } else {
            ROS_ERROR("Failed to load map: %s", path.c_str());
        }

        loop_timer_ = nh_.createTimer(ros::Duration(0.05), &ParkingSystem::controlLoop, this);
    }

    // ================= 初始化关键逻辑 =================
    bool initMissionParams() {
        bool has_start = false, has_slot = false;

        // 1. 解析 Apollo 泊车起始点 (9259)
        // 9259 可能是 Relation 或 Way，我们需要它的中心点和切线方向
        Way* w_start = findWayById(START_LANELET_CENTER_ID);
        Relation* r_start = findRelationById(START_LANELET_CENTER_ID);

        std::vector<std::pair<double,double>> pts_start;
        if (w_start) pts_start = getWayPoints(w_start);
        else if (r_start) pts_start = getRelationPoints(r_start);

        if (!pts_start.empty()) {
            // 计算中心点
            double sx=0, sy=0;
            for(auto& p : pts_start) { sx+=p.first; sy+=p.second; }
            pre_stop_x_ = sx / pts_start.size();
            pre_stop_y_ = sy / pts_start.size();
            
            // 计算方向 (取最后两个点的向量，或者平均向量)
            if (pts_start.size() >= 2) {
                size_t n = pts_start.size();
                double dx = pts_start[n-1].first - pts_start[0].first;
                double dy = pts_start[n-1].second - pts_start[0].second;
                pre_stop_theta_ = std::atan2(dy, dx);
            }
            has_start = true;
            ROS_INFO("Found Start Point (9259): (%.2f, %.2f), Theta: %.2f", pre_stop_x_, pre_stop_y_, pre_stop_theta_);
        }

        // 2. 解析车位边界线 (9386 & 9392)
        Way* wa = findWayById(LINESTR_ID_A);
        Way* wb = findWayById(LINESTR_ID_B);

        if (wa && wb) {
            slot_line_a_ = getWayPoints(wa);
            slot_line_b_ = getWayPoints(wb);

            if (!slot_line_a_.empty() && !slot_line_b_.empty()) {
                // 计算车位中心：两条线段所有点的平均值
                double tx=0, ty=0; int cnt=0;
                for(auto& p : slot_line_a_) { tx+=p.first; ty+=p.second; cnt++; }
                for(auto& p : slot_line_b_) { tx+=p.first; ty+=p.second; cnt++; }
                parking_target_x_ = tx / cnt;
                parking_target_y_ = ty / cnt;

                // 计算车位朝向：线的方向
                // 假设线段方向是从车库外向里，或者取两条线的平均向量
                double dx_a = slot_line_a_.back().first - slot_line_a_.front().first;
                double dy_a = slot_line_a_.back().second - slot_line_a_.front().second;
                double dx_b = slot_line_b_.back().first - slot_line_b_.front().first;
                double dy_b = slot_line_b_.back().second - slot_line_b_.front().second;
                
                // 平均向量
                parking_target_theta_ = std::atan2(dy_a + dy_b, dx_a + dx_b);
                
                // 修正：如果车位方向和 9259 的方向差了 180 度左右，说明线段定义方向反了
                // 通常泊车时车头朝外，或者根据具体地图定义
                // 这里假设 9259 指向车库，那么泊车最终朝向应该与 9259 垂直或反向？
                // 垂直泊车通常最终朝向与道路垂直。
                // 我们取使得车头朝外的方向（假设倒车入库）
                
                // 简单处理：使用几何计算，确保 target theta 指向 Pre-Stop 反方向（车头朝外）
                // 或者指向 Pre-Stop 方向（车头朝里）
                // 假设是倒车入库，最终车头朝向 Pre-Stop
                double dir_to_start = std::atan2(pre_stop_y_ - parking_target_y_, pre_stop_x_ - parking_target_x_);
                // 让 parking_target_theta_ 接近 dir_to_start
                if (std::abs(MapTools::normalizeAng(parking_target_theta_ - dir_to_start)) > M_PI/2) {
                    parking_target_theta_ = MapTools::normalizeAng(parking_target_theta_ + M_PI);
                }

                has_slot = true;
                ROS_INFO("Found Parking Slot (9386/9392): Center(%.2f, %.2f), Theta: %.2f", parking_target_x_, parking_target_y_, parking_target_theta_);
            }
        }

        return has_start && has_slot;
    }

    // ================= 控制循环 =================
    void controlLoop(const ros::TimerEvent&) {
        if (!mission_ready_) return;

        double dt = 0.05;
        updateScenarioState();

        switch (current_stage_) {
            case STAGE_IDLE: break;
            case STAGE_APPROACHING: processStageApproaching(); break;
            case STAGE_PARKING: processStageParking(); break;
            case STAGE_FINISHED: car_.v = 0.0; car_.phi = 0.0; break;
        }

        if (!global_plan_.empty() && current_stage_ != STAGE_FINISHED) {
            executeTrackingStep(dt);
            publishPlannedPath();
        }
        publishPose();
        visualizeSlot(); // 可视化车位线
    }

    // ================= 场景决策 =================
    void updateScenarioState() {
        if (current_stage_ == STAGE_FINISHED) return;
        double dist = std::hypot(car_.x - pre_stop_x_, car_.y - pre_stop_y_); // 距离 9259 的距离

        if (current_stage_ == STAGE_IDLE) {
            if (dist < config_.parking_spot_range_to_start * 2) {
                current_stage_ = STAGE_APPROACHING;
                global_plan_.clear(); current_idx_ = 0;
            }
        }
    }

    // ================= 阶段 1: 导航至 9259 (Pre-Stop) =================
    void processStageApproaching() {
        // 目标：9259 (Pre-Stop Point)
        if (global_plan_.empty()) {
            ROS_INFO("Planning path to Apollo Start Point (9259)...");
            long long start_node = findNearestAdjNode(car_.x, car_.y);
            long long end_node = findNearestAdjNode(pre_stop_x_, pre_stop_y_);
            
            std::vector<long long> nodes = bfs(start_node, end_node);
            if (!nodes.empty()) {
                global_plan_.clear();
                for (long long nid : nodes) {
                    CarState s; s.x = nodes_map_[nid].x; s.y = nodes_map_[nid].y; s.v = config_.approach_speed;
                    global_plan_.push_back(s);
                }
                // 最后插值对齐到 9259 的精确中心和角度
                CarState last = global_plan_.back();
                for(int i=1; i<=20; ++i) {
                    double t = i/20.0;
                    CarState s;
                    s.x = last.x + (pre_stop_x_ - last.x)*t;
                    s.y = last.y + (pre_stop_y_ - last.y)*t;
                    s.theta = pre_stop_theta_; // 对齐方向
                    s.v = config_.approach_speed * (1-t) + 0.1;
                    global_plan_.push_back(s);
                }
                current_idx_ = 0;
            } else {
                ROS_WARN("BFS Failed to 9259. Check map topology.");
            }
        }

        double d = std::hypot(car_.x - pre_stop_x_, car_.y - pre_stop_y_);
        bool stopped = std::abs(car_.v) < 0.1;

        // 到达 9259 附近且停稳
        if (d < config_.max_valid_stop_distance && current_idx_ >= global_plan_.size()-5) {
            if (!stopped) return; // 等待停稳
            ROS_INFO("Reached Pre-Stop (9259). Starting Parking Maneuver.");
            current_stage_ = STAGE_PARKING;
            global_plan_.clear(); current_idx_ = 0;
        }
    }

    // ================= 阶段 2: 倒库 (避开 9386/9392) =================
    void processStageParking() {
        if (!parking_trajectory_generated_) {
            ROS_INFO("Generating Trajectory into Slot...");
            // 生成倒车轨迹
            // 从当前(9259) 到 车位中心
            global_plan_ = generateGeometricParkingPath(car_, parking_target_x_, parking_target_y_, parking_target_theta_);
            current_idx_ = 0;
            parking_trajectory_generated_ = true;
        }

        // 碰撞检测！
        if (checkSlotCollision()) {
            ROS_ERROR("COLLISION WARNING: Too close to slot lines! Emergency Stop.");
            car_.v = 0.0;
            current_stage_ = STAGE_FINISHED; // 强制结束
            return;
        }

        double d = std::hypot(car_.x - parking_target_x_, car_.y - parking_target_y_);
        if (d < 0.1 && std::abs(car_.v) < 0.05) {
            ROS_INFO("Parking Success.");
            current_stage_ = STAGE_FINISHED;
        }
    }

    // ================= 碰撞检测逻辑 =================
    bool checkSlotCollision() {
        // 检查车辆四个角点与 Line A 和 Line B 的距离
        // 车辆轮廓
        double cos_t = cos(car_.theta), sin_t = sin(car_.theta);
        double hw = vehicle_width_ / 2.0;
        double hl = vehicle_length_ / 2.0;
        
        // 四个角点 (FL, FR, BL, BR)
        double corners[4][2] = {
            { car_.x + hl*cos_t - hw*sin_t, car_.y + hl*sin_t + hw*cos_t },
            { car_.x + hl*cos_t + hw*sin_t, car_.y + hl*sin_t - hw*cos_t },
            { car_.x - hl*cos_t - hw*sin_t, car_.y - hl*sin_t + hw*cos_t },
            { car_.x - hl*cos_t + hw*sin_t, car_.y - hl*sin_t - hw*cos_t }
        };

        for (int i=0; i<4; ++i) {
            double cx = corners[i][0];
            double cy = corners[i][1];
            
            // 检查 Line A
            for (size_t j=0; j+1 < slot_line_a_.size(); ++j) {
                double dist = MapTools::distToSegment(cx, cy, slot_line_a_[j].first, slot_line_a_[j].second, slot_line_a_[j+1].first, slot_line_a_[j+1].second);
                if (dist < 0.05) return true; // 碰撞
            }
            // 检查 Line B
            for (size_t j=0; j+1 < slot_line_b_.size(); ++j) {
                double dist = MapTools::distToSegment(cx, cy, slot_line_b_[j].first, slot_line_b_[j].second, slot_line_b_[j+1].first, slot_line_b_[j+1].second);
                if (dist < 0.05) return true; // 碰撞
            }
        }
        return false;
    }

    // ================= 几何倒车轨迹生成 =================
    std::vector<CarState> generateGeometricParkingPath(CarState start, double end_x, double end_y, double end_theta) {
        // 简单的人字形倒车：
        // 1. 直线后退
        std::vector<CarState> path;
        double dx = end_x - start.x;
        double dy = end_y - start.y;
        double dist = std::hypot(dx, dy);
        int steps = std::max(10, (int)(dist / 0.05));
        
        for(int i=0; i<=steps; ++i) {
            double t = (double)i / steps;
            CarState s;
            s.x = start.x + dx * t;
            s.y = start.y + dy * t;
            // 简单线性插值角度，实际需要更复杂的曲线来保证不压线
            s.theta = start.theta + MapTools::normalizeAng(end_theta - start.theta) * t;
            s.v = -config_.parking_speed;
            if (i > steps - 10) s.v *= 0.5;
            if (i == steps) s.v = 0.0;
            path.push_back(s);
        }
        return path;
    }

    // ================= 辅助函数 =================
    void executeTrackingStep(double dt) {
        if (current_idx_ >= global_plan_.size()) return;
        
        // 寻找预瞄点
        int look_idx = current_idx_;
        double look_dist = 1.5;
        for(int i=current_idx_; i<global_plan_.size(); ++i) {
            if(std::hypot(global_plan_[i].x - car_.x, global_plan_[i].y - car_.y) > look_dist) {
                look_idx = i; break;
            }
        }
        CarState target = global_plan_[look_idx];

        // 换挡逻辑
        if (car_.v * target.v < -0.01 || gear_shift_counter_ > 0) {
            if (gear_shift_counter_ == 0) gear_shift_counter_ = 20;
            car_.v = 0.0;
            gear_shift_counter_--;
            return;
        }

        // Pure Pursuit
        double alpha = MapTools::normalizeAng(atan2(target.y - car_.y, target.x - car_.x) - car_.theta);
        if (target.v < 0) alpha = MapTools::normalizeAng(atan2(target.y - car_.y, target.x - car_.x) - car_.theta - M_PI);
        double Ld = std::hypot(target.x - car_.x, target.y - car_.y);
        double delta = atan(2.0 * wheelbase_ * sin(alpha) / Ld);
        
        delta = std::max(-max_steering_rad_, std::min(max_steering_rad_, delta));
        car_.phi += (delta - car_.phi) * 0.2;
        car_.v = target.v;

        // Kinematics
        car_.x += car_.v * cos(car_.theta) * dt;
        car_.y += car_.v * sin(car_.theta) * dt;
        car_.theta += (car_.v / wheelbase_) * tan(car_.phi) * dt;
        car_.theta = MapTools::normalizeAng(car_.theta);

        if (std::hypot(target.x - car_.x, target.y - car_.y) < 0.5 && current_idx_ < global_plan_.size()-1) current_idx_++;
    }

    // BFS 搜索
    std::vector<long long> bfs(long long start, long long goal) {
        if(start == -1 || goal == -1) return {};
        std::queue<long long> q; q.push(start);
        std::map<long long, long long> came_from; came_from[start] = start;
        while(!q.empty()){
            long long curr = q.front(); q.pop();
            if(curr == goal) break;
            for(long long next : adjacency_list_[curr]){
                if(!came_from.count(next)){ came_from[next]=curr; q.push(next); }
            }
        }
        std::vector<long long> path;
        if(!came_from.count(goal)) return path;
        for(long long curr=goal; curr!=start; curr=came_from[curr]) path.push_back(curr);
        path.push_back(start);
        std::reverse(path.begin(), path.end());
        return path;
    }

    long long findNearestAdjNode(double x, double y) {
        long long best=-1; double min_d=1e18;
        for(auto& kv : adjacency_list_) {
            if(nodes_map_.count(kv.first)) {
                double d = std::hypot(nodes_map_[kv.first].x - x, nodes_map_[kv.first].y - y);
                if(d < min_d) { min_d=d; best=kv.first; }
            }
        }
        return best;
    }

    // 地图查询辅助
    Way* findWayById(long long id) { for(auto& w:ways_) if(w.id==id) return &w; return nullptr; }
    Relation* findRelationById(long long id) { for(auto& r:relations_) if(r.id==id) return &r; return nullptr; }
    
    std::vector<std::pair<double,double>> getWayPoints(Way* w) {
        std::vector<std::pair<double,double>> pts;
        for(long long nid : w->node_refs) if(nodes_map_.count(nid)) pts.push_back({nodes_map_[nid].x, nodes_map_[nid].y});
        return pts;
    }
    
    std::vector<std::pair<double,double>> getRelationPoints(Relation* r) {
        std::vector<std::pair<double,double>> pts;
        for(long long wid : r->member_way_refs) {
            Way* w = findWayById(wid);
            if(w) { auto sub = getWayPoints(w); pts.insert(pts.end(), sub.begin(), sub.end()); }
        }
        return pts;
    }

    // ================= 地图加载 (保持原样) =================
    bool loadMap(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) return false;
        std::string line;
        while (std::getline(file, line)) {
            if (line.find("<node") != std::string::npos) {
                NodePoint n;
                n.id = std::stoll(extractAttr(line, "id"));
                n.lat = std::stod(extractAttr(line, "lat"));
                n.lon = std::stod(extractAttr(line, "lon"));
                nodes_map_[n.id] = n;
            } else if (line.find("<way") != std::string::npos) {
                Way w; w.id = std::stoll(extractAttr(line, "id"));
                while (std::getline(file, line) && line.find("</way>") == std::string::npos) {
                    if (line.find("<nd") != std::string::npos) w.node_refs.push_back(std::stoll(extractAttr(line, "ref")));
                }
                ways_.push_back(w);
            } else if (line.find("<relation") != std::string::npos) {
                Relation r; r.id = std::stoll(extractAttr(line, "id"));
                while (std::getline(file, line) && line.find("</relation>") == std::string::npos) {
                    if (line.find("<member") != std::string::npos && extractAttr(line, "type") == "way") 
                        r.member_way_refs.push_back(std::stoll(extractAttr(line, "ref")));
                }
                relations_.push_back(r);
            }
        }
        return true;
    }

    std::string extractAttr(const std::string& line, const std::string& key) {
        std::string search = key + "=\"";
        size_t start = line.find(search);
        if (start == std::string::npos) { search = key + "='"; start = line.find(search); }
        if (start == std::string::npos) return "";
        start += search.length();
        size_t end = line.find_first_of("\"'", start);
        return line.substr(start, end - start);
    }

    void buildGraph() {
        for (const auto& w : ways_) {
            for (size_t i = 0; i + 1 < w.node_refs.size(); ++i) {
                adjacency_list_[w.node_refs[i]].push_back(w.node_refs[i+1]);
                adjacency_list_[w.node_refs[i+1]].push_back(w.node_refs[i]);
            }
        }
    }

    // ================= 可视化 =================
    void publishPose() {
        static tf::TransformBroadcaster br;
        tf::Transform transform;
        transform.setOrigin(tf::Vector3(car_.x, car_.y, 0.0));
        tf::Quaternion q; q.setRPY(0, 0, car_.theta);
        transform.setRotation(q);
        br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "map", "base_link"));

        geometry_msgs::Pose2D p2d; p2d.x = car_.x; p2d.y = car_.y; p2d.theta = car_.theta;
        pose_pub_.publish(p2d);
        
        visualization_msgs::MarkerArray arr;
        visualization_msgs::Marker m;
        m.header.frame_id = "map"; m.header.stamp = ros::Time::now(); m.id = 0;
        m.type = visualization_msgs::Marker::CUBE;
        m.pose.position.x = car_.x; m.pose.position.y = car_.y; m.pose.position.z = 0.5;
        m.pose.orientation = tf::createQuaternionMsgFromYaw(car_.theta);
        m.scale.x = vehicle_length_; m.scale.y = vehicle_width_; m.scale.z = 1.0;
        m.color.a = 0.8; m.color.g = 1.0;
        arr.markers.push_back(m);
        car_pub_.publish(arr);
    }
    
    void publishPlannedPath() {
        nav_msgs::Path p; p.header.frame_id = "map"; p.header.stamp = ros::Time::now();
        for(auto& s : global_plan_) {
            geometry_msgs::PoseStamped ps;
            ps.pose.position.x = s.x; ps.pose.position.y = s.y;
            ps.pose.orientation = tf::createQuaternionMsgFromYaw(s.theta);
            p.poses.push_back(ps);
        }
        path_pub_.publish(p);
    }
    
    void publishMap() {
        visualization_msgs::MarkerArray arr;
        visualization_msgs::Marker m;
        m.header.frame_id = "map"; m.header.stamp = ros::Time::now();
        m.ns = "ways"; m.type = visualization_msgs::Marker::LINE_LIST;
        m.scale.x = 0.1; m.color.a = 0.5; m.color.r = 1.0; m.color.g = 1.0; m.color.b = 1.0;
        for(const auto& w : ways_) {
            for(size_t i=0; i+1<w.node_refs.size(); ++i) {
                if(nodes_map_.count(w.node_refs[i]) && nodes_map_.count(w.node_refs[i+1])){
                    geometry_msgs::Point p1, p2;
                    p1.x = nodes_map_[w.node_refs[i]].x; p1.y = nodes_map_[w.node_refs[i]].y;
                    p2.x = nodes_map_[w.node_refs[i+1]].x; p2.y = nodes_map_[w.node_refs[i+1]].y;
                    m.points.push_back(p1); m.points.push_back(p2);
                }
            }
        }
        arr.markers.push_back(m);
        ways_pub_.publish(arr);
    }

    void visualizeSlot() {
        visualization_msgs::MarkerArray arr;
        // 车位边界线 (Red)
        visualization_msgs::Marker m; m.header.frame_id="map"; m.ns="slot_lines"; m.type=visualization_msgs::Marker::LINE_STRIP; m.scale.x=0.2; m.color.a=1.0; m.color.r=1.0;
        m.id=0; 
        for(auto& p:slot_line_a_) { geometry_msgs::Point pt; pt.x=p.first; pt.y=p.second; m.points.push_back(pt); }
        arr.markers.push_back(m);
        
        m.id=1; m.points.clear();
        for(auto& p:slot_line_b_) { geometry_msgs::Point pt; pt.x=p.first; pt.y=p.second; m.points.push_back(pt); }
        arr.markers.push_back(m);

        // Pre-Stop Point (Green Sphere)
        visualization_msgs::Marker ps; ps.header.frame_id="map"; ps.ns="pre_stop"; ps.type=visualization_msgs::Marker::SPHERE; ps.scale.x=1.0; ps.scale.y=1.0; ps.scale.z=1.0;
        ps.pose.position.x = pre_stop_x_; ps.pose.position.y = pre_stop_y_; 
        ps.color.a=1.0; ps.color.g=1.0;
        arr.markers.push_back(ps);

        parking_pub_.publish(arr);
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "real_map_parking_node");
    ParkingSystem ps;
    ros::spin();
    return 0;
}